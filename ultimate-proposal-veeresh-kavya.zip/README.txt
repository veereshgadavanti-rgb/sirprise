ADD EXACTLY:

BACKGROUND PHOTO:
background/bg.jpg
(best romantic photo of both of you)

PHOTOS:
photos/photo1.jpg → first memory photo
photos/photo2.jpg → favorite photo
photos/photo3.jpg → recent photo

MUSIC:
music/music.mp3 → your special romantic song

OPEN:
index.html

UPLOAD TO NETLIFY

SEND LINK ❤️
